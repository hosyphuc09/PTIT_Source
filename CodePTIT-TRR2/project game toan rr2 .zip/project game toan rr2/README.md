# DFS - BFS Spanning Tree Game

## 📌 Giới thiệu
Đây là một game console được viết bằng C++ giúp người dùng luyện tập và hiểu rõ hơn về thuật toán:

- DFS (Depth First Search)
- BFS (Breadth First Search)

Người chơi sẽ chọn các cạnh để tạo thành cây khung (spanning tree) đúng theo thuật toán DFS hoặc BFS từ một đỉnh bắt đầu ngẫu nhiên.

---

## 🎮 Cách chơi

Khi chạy chương trình, bạn sẽ thấy:

- Danh sách cạnh của đồ thị
- Node bắt đầu (start node)
- Số cạnh cần chọn = n - 1

### 🔹 Điều khiển:
- Nhập số cạnh (1 → m): chọn / bỏ chọn cạnh
- `0`: kiểm tra đáp án
- `H`: gợi ý (hint)
- `Q`: thoát game

---

## ⚙️ Cách chạy chương trình (Dev-C++)

### 🔸 Cách 1 (1 file):
- Mở `main.cpp`
- Nhấn F11 hoặc Execute → Compile & Run

---

### 🔸 Cách 2 (nhiều file):
- Tạo Project trong Dev-C++
- Thêm các file:
  - code.cpp
  
- Nhấn F11 để chạy